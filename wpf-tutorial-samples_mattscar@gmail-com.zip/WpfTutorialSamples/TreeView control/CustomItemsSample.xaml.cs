﻿using System;
using System.Windows;

namespace WpfTutorialSamples.TreeView_control
{
	public partial class CustomItemsSample : Window
	{
		public CustomItemsSample()
		{
			InitializeComponent();
		}
	}
}
