﻿using System;
using System.Windows;

namespace WpfTutorialSamples.Control_concepts
{
	public partial class ToolTipsSimpleSample : Window
	{
		public ToolTipsSimpleSample()
		{
			InitializeComponent();
		}
	}
}
