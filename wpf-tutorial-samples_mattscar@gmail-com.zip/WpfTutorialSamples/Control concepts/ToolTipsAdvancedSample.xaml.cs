﻿using System;
using System.Windows;

namespace WpfTutorialSamples.Control_concepts
{
	public partial class ToolTipsAdvancedSample : Window
	{
		public ToolTipsAdvancedSample()
		{
			InitializeComponent();
		}
	}
}
