﻿using System;
using System.Windows;

namespace WpfTutorialSamples.Misc_controls
{
	public partial class CalendarViewboxSample : Window
	{
		public CalendarViewboxSample()
		{
			InitializeComponent();
		}
	}
}
