﻿using System;
using System.Windows;

namespace WpfTutorialSamples.Misc_controls
{
	public partial class ProgressBarTextSample : Window
	{
		public ProgressBarTextSample()
		{
			InitializeComponent();
		}
	}
}
