﻿using System;
using System.Windows;

namespace WpfTutorialSamples.Misc_controls
{
	public partial class SliderBoundValueSample : Window
	{
		public SliderBoundValueSample()
		{
			InitializeComponent();			
		}
	}
}
