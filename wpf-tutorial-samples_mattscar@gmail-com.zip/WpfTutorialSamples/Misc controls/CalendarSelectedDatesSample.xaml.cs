﻿using System;
using System.Windows;

namespace WpfTutorialSamples.Misc_controls
{
	public partial class CalendarSelectedDatesSample : Window
	{
		public CalendarSelectedDatesSample()
		{
			InitializeComponent();			
		}
	}
}
