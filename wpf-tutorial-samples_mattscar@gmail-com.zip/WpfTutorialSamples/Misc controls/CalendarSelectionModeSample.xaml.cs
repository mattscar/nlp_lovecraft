﻿using System;
using System.Windows;

namespace WpfTutorialSamples.Misc_controls
{
	public partial class CalendarSelectionModeSample : Window
	{
		public CalendarSelectionModeSample()
		{
			InitializeComponent();
		}
	}
}
