﻿using System;
using System.Windows;

namespace WpfTutorialSamples.ItemsControl
{
	public partial class PanelSample : Window
	{
		public PanelSample()
		{
			InitializeComponent();
		}
	}
}
