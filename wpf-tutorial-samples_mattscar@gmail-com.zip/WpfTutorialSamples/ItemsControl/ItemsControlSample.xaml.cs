﻿using System;
using System.Windows;

namespace WpfTutorialSamples.ItemsControl
{
	public partial class ItemsControlSample : Window
	{
		public ItemsControlSample()
		{
			InitializeComponent();
		}
	}
}
