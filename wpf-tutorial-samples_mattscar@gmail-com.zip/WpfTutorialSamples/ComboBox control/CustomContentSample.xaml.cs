﻿using System;
using System.Windows;

namespace WpfTutorialSamples.ComboBox_control
{
	public partial class CustomContentSample : Window
	{
		public CustomContentSample()
		{
			InitializeComponent();
		}
	}
}
