﻿using System;
using System.Windows;

namespace WpfTutorialSamples.ComboBox_control
{
	public partial class EditableSample : Window
	{
		public EditableSample()
		{
			InitializeComponent();
		}
	}
}
