﻿using System;
using System.Windows;
using System.Windows.Media;

namespace WpfTutorialSamples.Audio_and_Video
{
	public partial class MediaPlayerVideoSample : Window
	{
		public MediaPlayerVideoSample()
		{
			InitializeComponent();
		}
	}
}
