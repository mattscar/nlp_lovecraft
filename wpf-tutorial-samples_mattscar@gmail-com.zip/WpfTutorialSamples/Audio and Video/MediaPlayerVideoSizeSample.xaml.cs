﻿using System;
using System.Windows;

namespace WpfTutorialSamples.Audio_and_Video
{
	public partial class MediaPlayerVideoSizeSample : Window
	{
		public MediaPlayerVideoSizeSample()
		{
			InitializeComponent();
		}
	}
}
