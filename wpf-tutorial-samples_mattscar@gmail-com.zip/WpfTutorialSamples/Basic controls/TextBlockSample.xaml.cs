﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace WpfTutorialSamples.Basic_controls
{
	/// <summary>
	/// Interaction logic for TextBlock.xaml
	/// </summary>
	public partial class TextBlockSample : Window
	{
		public TextBlockSample()
		{
			InitializeComponent();
		}
	}
}
