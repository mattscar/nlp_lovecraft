﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace WpfTutorialSamples.Rich_text_controls
{
	public partial class FlowDocumentScrollViewerZoomSample : Window
	{
		public FlowDocumentScrollViewerZoomSample()
		{
			InitializeComponent();
		}
	}
}
