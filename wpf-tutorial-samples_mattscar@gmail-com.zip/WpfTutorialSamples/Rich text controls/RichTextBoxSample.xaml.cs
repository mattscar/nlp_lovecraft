﻿using System;
using System.Windows;

namespace WpfTutorialSamples.Rich_text_controls
{
	public partial class RichTextBoxSample : Window
	{
		public RichTextBoxSample()
		{
			InitializeComponent();
		}
	}
}
