﻿using System;
using System.Windows;

namespace WpfTutorialSamples.WPF_Application
{
	public partial class ExtendedResourceSample : Window
	{
		public ExtendedResourceSample()
		{
			InitializeComponent();
		}
	}
}
