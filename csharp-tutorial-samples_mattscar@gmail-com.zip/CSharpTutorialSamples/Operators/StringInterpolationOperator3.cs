﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Operators
{
    [SampleInfo(414, 5412)]
    public class StringInterpolationOperator3 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            double daysSinceMillenium = (DateTime.Now - new DateTime(2000, 1, 1)).TotalDays;
            Console.WriteLine($"Today is {DateTime.Now:d} and {daysSinceMillenium:N2} days have passed since the last millennium!");
        }
    }

}
