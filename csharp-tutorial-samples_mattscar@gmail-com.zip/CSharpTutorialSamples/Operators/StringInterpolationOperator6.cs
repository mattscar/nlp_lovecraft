﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Operators
{
    [SampleInfo(414, 5423)]
    public class StringInterpolationOperator6 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            Console.WriteLine($"5 + 5 * 2 = {((5 + 5) * 2)}");
        }
    }

}
