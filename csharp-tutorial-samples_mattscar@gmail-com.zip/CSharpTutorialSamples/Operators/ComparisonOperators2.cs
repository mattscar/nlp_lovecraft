﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(394, 5099)]
	public class ComparisonOperators2 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			int val1 = 42;
			int val2 = 43;
			if(val1 != val2)
				Console.WriteLine(val1 + " is NOT equal to " + val2);
		}
	}

}
