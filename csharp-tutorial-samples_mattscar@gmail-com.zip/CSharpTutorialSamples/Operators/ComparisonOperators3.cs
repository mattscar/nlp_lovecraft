﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(394, 5102)]
	public class ComparisonOperators3 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			int val1 = 42;
			int val2 = 43;
			if(val1 > val2)
				Console.WriteLine(val1 + " is larger than " + val2);
			else
			{
				if(val1 < val2)
					Console.WriteLine(val1 + " is smaller than " + val2);
				else
					Console.WriteLine(val1 + " is equal to " + val2);
			}
		}
	}

}
