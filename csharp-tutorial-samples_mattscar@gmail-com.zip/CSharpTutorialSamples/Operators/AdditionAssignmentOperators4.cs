﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Operators
{
	[SampleInfo(396, 5076)]
	public class AdditionAssignmentOperators4 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			string userName = "John";
			userName += " Doe";
			Console.WriteLine(userName);
		}
	}

}
