﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Operators
{
	[SampleInfo(396, 5069)]
	public class AdditionAssignmentOperators2 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			int userAge = 42;			
			userAge -= 4;
			Console.WriteLine(userAge);
		}
	}


}
