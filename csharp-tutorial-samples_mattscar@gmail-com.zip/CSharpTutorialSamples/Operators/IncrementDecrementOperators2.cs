﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Operators
{
	[SampleInfo(395, 5053)]
	public class IncrementDecrementOperators2 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			int userAge = 41;
			Console.WriteLine("Age of user: " + ++userAge);
		}
	}

}
