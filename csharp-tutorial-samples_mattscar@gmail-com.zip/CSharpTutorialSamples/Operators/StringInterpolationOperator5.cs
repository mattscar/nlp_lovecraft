﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Operators
{
    [SampleInfo(414, 5421)]
    public class StringInterpolationOperator5 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            string name = "John Doe";
            int age = 42;

            Console.WriteLine($"{name} is {age} year{(age == 1 ? "" : "s")} old");
        }
    }

}
