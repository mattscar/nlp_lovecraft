﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Operators
{
	[SampleInfo(394, 5347)]
	public class ComparisonOperators4 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			int val1 = 42;
			if(val1 >= 42)
				Console.WriteLine("val1 is larger than or equal to 42");
			if(val1 <= 42)
				Console.WriteLine("val1 is smaller than or equal to 42");
		}
	}

}
