﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Operators
{
    [SampleInfo(414, 5409)]
    public class StringInterpolationOperator2 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            var user = new
            {
                Name = "John Doe",
                Age = 42
            };
            Console.WriteLine($"{user.Name} is {user.Age} years old");
        }
    }
}
