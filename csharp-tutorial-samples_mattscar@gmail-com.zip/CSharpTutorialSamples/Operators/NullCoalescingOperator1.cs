﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Operators
{
	[SampleInfo(397, 5081)]
	public class NullCoalescingOperator1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			string userSuppliedName = null;

			Console.WriteLine("Hello, " + (userSuppliedName ?? "Anonymous")); 
		}
	}

}
