﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Operators
{
	[SampleInfo(396, 5071)]
	public class AdditionAssignmentOperators3 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			int userAge = 42;

			userAge *= 2;
			Console.WriteLine("User age: " + userAge);

			userAge /= 2;
			Console.WriteLine("User age: " + userAge);
		}
	}

}
