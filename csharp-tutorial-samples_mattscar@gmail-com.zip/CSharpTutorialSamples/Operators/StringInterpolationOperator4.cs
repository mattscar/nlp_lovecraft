﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Operators
{
    [SampleInfo(414, 5417)]
    public class StringInterpolationOperator4 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            Console.WriteLine($"Today is {DateTime.Now:yyyy-MM-dd}");
        }
    }

}
