﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Operators
{
	[SampleInfo(395, 5047)]
	public class IncrementDecrementOperators1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			int userAge = 41;
			userAge++;
			Console.WriteLine("Age of user: " + userAge);
		}
	}

}
