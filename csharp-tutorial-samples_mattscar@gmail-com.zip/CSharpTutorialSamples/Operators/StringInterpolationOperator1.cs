﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Operators
{
	[SampleInfo(414, 5407)]
	public class StringInterpolationOperator1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			string name = "John Doe";
			int age = 42;

			Console.WriteLine(name + " is " + age + " years old");
			Console.WriteLine($"{name} is {age} years old");
		}
	}

}
