﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Operators
{
	[SampleInfo(396, 5067)]
	public class AdditionAssignmentOperators1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			int userAge = 38;
			userAge += 4;
			Console.WriteLine(userAge);
		}
	}

}
