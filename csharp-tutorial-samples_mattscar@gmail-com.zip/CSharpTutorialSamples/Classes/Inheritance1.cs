﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Classes
{
	[SampleInfo(122, 2115)]
	public class Inheritance1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			Animal animal = new Animal();
			animal.Greet();

			Dog dog = new Dog();
			dog.Greet();
		}

		public class Animal
		{
			public virtual void Greet()
			{
				Console.WriteLine("Hello, I'm some sort of animal!");
			}
		}

		public class Dog : Animal
		{
			public override void Greet()
			{				
				Console.WriteLine("Yes I am - a dog!");
			}
		}
	}
}
