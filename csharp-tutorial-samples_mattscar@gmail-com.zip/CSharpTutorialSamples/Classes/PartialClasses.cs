﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Classes
{
	[SampleInfo(415, 5470)]
	public class PartialClasses : IConsoleAppSample
	{
		public void Main(string[] args)
		{

			PartialClass pc = new PartialClass();
			pc.HelloWorld();
			pc.HelloUniverse();

		}

		public partial class PartialClass
		{
			public void HelloWorld()
			{
				Console.WriteLine("Hello, world!");
			}
		}

		public partial class PartialClass
		{
			public void HelloUniverse()
			{
				Console.WriteLine("Hello, universe!");
			}
		}
	}

}
