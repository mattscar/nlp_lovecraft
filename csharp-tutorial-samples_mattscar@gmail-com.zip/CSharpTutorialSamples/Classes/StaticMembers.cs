﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Classes
{
	[SampleInfo(121, 2106)]
	public class StaticMembers : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			Rectangle rectangle = new Rectangle(200, 100);
			rectangle.OutputArea();

			Console.WriteLine("Static rectangle area calculation: " + Rectangle.CalculateArea(100, 50));
		}

		class Rectangle
		{
			private int width, height;

			public Rectangle(int width, int height)
			{
				this.width = width;
				this.height = height;
			}

			public void OutputArea()
			{
				Console.WriteLine("Area output: " + Rectangle.CalculateArea(this.width, this.height));
			}

			public static int CalculateArea(int width, int height)
			{
				return width * height;
			}
		}
	}
}