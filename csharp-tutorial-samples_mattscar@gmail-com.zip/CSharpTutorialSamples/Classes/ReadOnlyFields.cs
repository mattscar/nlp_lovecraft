﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Classes
{
	[SampleInfo(407, 5352)]
	public class ReadOnlyFields : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			SomeClass someClass = new SomeClass();
			Console.WriteLine(someClass.later);
		}

		class SomeClass
		{
			private readonly DateTime rightNow;
			public readonly DateTime later = DateTime.Now.AddHours(2);

			public SomeClass()
			{
				this.rightNow = DateTime.Now;
			}
		}
	}
}
