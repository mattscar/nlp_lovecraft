﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Classes
{
	[SampleInfo(123, 2132)]
	public class AbstractClasses2 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			Dog dog = new Dog();
			Console.WriteLine(dog.Describe());
		}

		abstract class FourLeggedAnimal
		{
			public virtual string Describe()
			{
				return "This animal has four legs.";
			}
		}


		class Dog : FourLeggedAnimal
		{
			public override string Describe()
			{
				string result = base.Describe();
				result += " In fact, it's a dog!";
				return result;
			}
		}
	}
}
