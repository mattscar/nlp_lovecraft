﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Classes
{
	[SampleInfo(124, 2137)]
	public class AbstractClasses3 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			System.Collections.ArrayList animalList = new System.Collections.ArrayList();
			animalList.Add(new Dog());
			animalList.Add(new Cat());
			foreach(FourLeggedAnimal animal in animalList)
				Console.WriteLine(animal.Describe());
			
		}

		abstract class FourLeggedAnimal
		{
			public abstract string Describe();
		}


		class Dog : FourLeggedAnimal
		{
			public override string Describe()
			{
				return "I'm a dog!";
			}
		}

		class Cat : FourLeggedAnimal
		{
			public override string Describe()
			{
				return "I'm a cat!";

			}
		}

	}
}
