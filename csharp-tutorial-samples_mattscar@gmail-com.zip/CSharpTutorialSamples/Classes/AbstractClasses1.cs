﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Classes
{
	[SampleInfo(123, 2124)]
	public class AbstractClasses1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			Dog dog = new Dog();
			Console.WriteLine(dog.Describe());
		}


		abstract class FourLeggedAnimal
		{
			public virtual string Describe()
			{
				return "Not much is known about this four legged animal!";
			}
		}

		class Dog : FourLeggedAnimal
		{

		}
	}
}
