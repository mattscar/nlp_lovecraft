﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Classes
{
	[SampleInfo(407, 5332)]
	public class Constants1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			Console.WriteLine("The fake answer to life: " + SomeClass.TheFakeAnswerToLife);
			Console.WriteLine("The real answer to life: " + SomeClass.GetAnswer());
		}

		class SomeClass
		{
			private const int TheAnswerToLife = 42;
			public const int TheFakeAnswerToLife = 43;

			public static int GetAnswer()
			{
				return TheAnswerToLife;

			}
		}

	}
}