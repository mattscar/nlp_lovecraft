﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Collections
{
	[SampleInfo(115, 2036)]
	public class Arrays1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{

			string[] names = new string[2];

			names[0] = "John Doe";
			names[1] = "Jane Doe";

			foreach(string s in names)
				Console.WriteLine(s);

			Console.ReadLine();

		}
	}

}
