﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Collections
{
	[SampleInfo(390, 5121)]
	public class Dictionaries3 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			Dictionary<string, int> users = new Dictionary<string, int>()
			{
			  { "John Doe", 42 },
			  { "Jane Doe", 38 },
			  { "Joe Doe", 12 },
			  { "Jenna Doe", 12 }
			};
			foreach(KeyValuePair<string, int> user in users.OrderBy(user => user.Value))
			{
				Console.WriteLine(user.Key + " is " + user.Value + " years old");
			}
		}
	}

}
