﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Collections
{
	[SampleInfo(115, 2038)]
	public class Arrays2 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			string[] names = new string[2];

			names[0] = "John Doe";
			names[1] = "Jane Doe";

			for(int i = 0; i < names.Length; i++)
				Console.WriteLine("Item number " + i + ": " + names[i]);
		}
	}

}
