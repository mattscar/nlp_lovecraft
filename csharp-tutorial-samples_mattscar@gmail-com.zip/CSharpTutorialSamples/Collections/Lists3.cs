﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Collections
{
	[SampleInfo(389, 5027)]
	public class Lists3 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			List<string> listOfNames = new List<string>()
			{
			  "John Doe",
			  "Jane Doe",
			  "Joe Doe",
			  "Another Doe"
			};

			listOfNames.Remove("Joe Doe");

			foreach(string name in listOfNames)
				Console.WriteLine(name);
		}
	}
}
