﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Collections
{
	[SampleInfo(389, 5633)]
	public class Lists5 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			List<string> listOfNames = new List<string>()
			{
			  "John Doe",
			  "Jane Doe",
			  "Joe Doe",
			  "Another Doe"
			};
			listOfNames.Sort();
			foreach(string name in listOfNames)
				Console.WriteLine(name);
		}
	}

}
