﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Collections
{
	[SampleInfo(390, 5107)]
	public class Dictionaries1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			Dictionary<string, int> users = new Dictionary<string, int>();
			users.Add("John Doe", 42);
			users.Add("Jane Doe", 38);
			users.Add("Joe Doe", 12);
			users.Add("Jenna Doe", 12);

			Console.WriteLine("John Doe is " + users["John Doe"] + " years old");
		}
	}

}
