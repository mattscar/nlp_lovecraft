﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Collections
{
	[SampleInfo(115, 2047)]
	public class Arrays3 : IConsoleAppSample
	{
		public void Main(string[] args)
		{

			int[] numbers = { 4, 3, 8, 0, 5 };

			Array.Sort(numbers);

			foreach(int i in numbers)
				Console.WriteLine(i);

			Console.ReadLine();

		}
	}

}
