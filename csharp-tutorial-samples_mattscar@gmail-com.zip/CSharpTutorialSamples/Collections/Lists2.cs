﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Collections
{
	[SampleInfo(389, 5015)]
	public class Lists2 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			List<string> listOfNames = new List<string>()
			{
			  "Joe Doe"
			};
			// Insert at the top (index 0)
			listOfNames.Insert(0, "John Doe");
			// Insert in the middle (index 1)
			listOfNames.Insert(1, "Jane Doe");

			foreach(string name in listOfNames)
				Console.WriteLine(name);
		}
	}

}
