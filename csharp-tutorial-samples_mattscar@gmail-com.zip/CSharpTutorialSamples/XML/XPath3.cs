﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace CSharpTutorial.Samples.XML
{
    [SampleInfo(138, 2261)]
    public class XPath3 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load("http://rss.cnn.com/rss/edition_world.rss");
            XmlNodeList titleNodes = xmlDoc.SelectNodes("//rss/channel/item/title");
            foreach (XmlNode titleNode in titleNodes)
                Console.WriteLine(titleNode.InnerText);
         
        }
    }

}
