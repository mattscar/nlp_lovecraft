﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples
{
	public interface IConsoleAppSample : ISample
	{
		void Main(string[] args);
		
	}
}
