﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(406, 5398)]
	public class ExpandoObjects2 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			dynamic user = new System.Dynamic.ExpandoObject();
			user.Name = "John Doe";
			user.Age = 42;

			user.HomeTown = new System.Dynamic.ExpandoObject();
			user.HomeTown.Name = "New York";
			user.HomeTown.ZipCode = 10001;

			Console.WriteLine(user.Name + " is " + user.Age + " years old and lives in " + user.HomeTown.Name + " [" + user.HomeTown.ZipCode + "]");
		}
	}

}
