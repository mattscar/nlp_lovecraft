﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(406, 5401)]
	public class ExpandoObjects4 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			dynamic user = new System.Dynamic.ExpandoObject();
			user.Name = "John Doe";
			user.Age = 42;

			foreach(KeyValuePair<string, object> kvp in user)
			{
				Console.WriteLine(kvp.Key + ": " + kvp.Value);
			}
		}
	}

}
