﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(406, 5399)]
	public class ExpandoObjects3 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			dynamic user = new System.Dynamic.ExpandoObject();
			user.Name = "John Doe";
			user.Age = 42;

			user.DescribeUser = (Func<String>)(() =>
			{
				return user.Name + " is " + user.Age + " years old and lives in " + user.HomeTown.Name + " [" + user.HomeTown.ZipCode + "]";
			});

			Console.WriteLine(user.DescribeUser());
		}
	}

}
