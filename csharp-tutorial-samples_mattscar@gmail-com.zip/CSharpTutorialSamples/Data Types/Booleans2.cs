﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(383, 5130)]
	public class Booleans2 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			bool isAdult = true;
			if(!isAdult)
				Console.WriteLine("NOT an adult");
			else
				Console.WriteLine("An adult");
		}
	}

}
