﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(382, 5362)]
	public class Nullables2 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			int? nullable = 42;

			if(nullable.Value == 42)
				Console.WriteLine("It's 42!");

			if(nullable == 42)
				Console.WriteLine("It's 42!");
		}
	}

}
