﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(381, 5194)]
	public class Floats1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			float a = 10f / 3;
			Console.WriteLine(a);
			double b = 10d / 3;
			Console.WriteLine(b);
			decimal c = 10m / 3;
			Console.WriteLine(c);
		}
	}

}
