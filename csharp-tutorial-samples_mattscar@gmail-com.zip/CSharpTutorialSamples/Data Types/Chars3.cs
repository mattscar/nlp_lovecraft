﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(384, 5289)]
	public class Chars3 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			Console.WriteLine("Enter a single number:");
			char ch = Console.ReadKey(true).KeyChar;
			if(Char.IsDigit(ch))
				Console.WriteLine("Thank you!");
			else
				Console.WriteLine("Wrong - please try again!");
		}
	}

}
