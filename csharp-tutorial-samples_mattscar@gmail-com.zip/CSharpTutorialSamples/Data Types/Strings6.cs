﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(385, 5438)]
	public class Strings6 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			string name = "John Doe";
			if((name.StartsWith("John")) && (name.EndsWith("Doe")))
				Console.WriteLine("Hello, Mr. Doe!");
		}
	}

}
