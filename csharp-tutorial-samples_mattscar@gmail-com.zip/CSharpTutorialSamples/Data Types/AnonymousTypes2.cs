﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(410, 5518)]
	public class AnonymousTypes2 : IConsoleAppSample
	{
		public void Main(string[] args)
		{

			string pathOfExe = System.Reflection.Assembly.GetEntryAssembly().Location;
			FileInfo fileInfo = new FileInfo(pathOfExe);
			var simpleFileInfo = new
			{
				Filename = fileInfo.Name,
				FileSize = fileInfo.Length
			};
			Console.WriteLine("File name: " + simpleFileInfo.Filename + ". Size: " + simpleFileInfo.FileSize + " bytes");

		}
	}

}
