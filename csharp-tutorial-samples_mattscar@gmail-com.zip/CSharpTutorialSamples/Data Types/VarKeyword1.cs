﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(402, 5186)]
	public class VarKeyword1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			var myObj = new
			{
				Name = "John Doe",
				Age = 42
			};
			Console.WriteLine(myObj.Name);
		}
	}

}
