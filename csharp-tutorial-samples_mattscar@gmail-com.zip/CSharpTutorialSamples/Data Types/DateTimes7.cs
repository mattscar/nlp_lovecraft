﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(401, 5446)]
	public class DateTimes7 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			var usCulture = new System.Globalization.CultureInfo("en-US");
			Console.WriteLine("Please specify a date. Format: " + usCulture.DateTimeFormat.ShortDatePattern);
			string dateString = Console.ReadLine();
			DateTime userDate;
			if(DateTime.TryParse(dateString, usCulture.DateTimeFormat, System.Globalization.DateTimeStyles.None, out userDate))
				Console.WriteLine("Valid date entered (long date format):" + userDate.ToLongDateString());
			else
				Console.WriteLine("Invalid date specified!");
		}
	}

}
