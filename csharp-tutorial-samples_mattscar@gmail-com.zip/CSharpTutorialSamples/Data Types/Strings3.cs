﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(385, 5433)]
	public class Strings3 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			string name = "John Doe";
			int indexOfSpace = name.IndexOf(' ') + 1;
			string lastName = name.Substring(indexOfSpace, name.Length - indexOfSpace);
			Console.WriteLine(lastName);
		}
	}

}
