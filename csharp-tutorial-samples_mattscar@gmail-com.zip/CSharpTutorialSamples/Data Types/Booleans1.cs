﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(383, 5128)]
	public class Booleans1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			bool isAdult = true;
			if(isAdult == true)
				Console.WriteLine("An adult");
			else
				Console.WriteLine("A child");
		}
	}

}
