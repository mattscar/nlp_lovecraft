﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(405, 5393)]
	public class DynamicKeyword2 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			dynamic user = new
			{
				Name = "John Doe",
				Age = 42
			};
			Console.WriteLine(user.GetType() + ": " + user.Name + " is " + user.Age + " years old");
			user = "Jane Doe";
			Console.WriteLine(user.GetType() + ": String.Length = " + user.Length);
		}
	}

}
