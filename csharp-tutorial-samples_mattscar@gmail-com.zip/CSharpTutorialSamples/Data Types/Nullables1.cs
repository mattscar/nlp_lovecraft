﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(382, 5358)]
	public class Nullables1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			int? nullable = null;
			if(nullable == null)
				Console.WriteLine("It's a null!");
			if(nullable.HasValue)
				Console.WriteLine("It's a null!");
		}
	}

}
