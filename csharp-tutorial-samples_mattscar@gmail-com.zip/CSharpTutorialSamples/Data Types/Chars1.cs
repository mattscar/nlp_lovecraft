﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(384, 5283)]
	public class Chars1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			string helloWorld = "Hello, world!";
			foreach(char c in helloWorld)
			{
				Console.WriteLine(c);
			}
		}
	}

}
