﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(401, 5249)]
	public class DateTimes1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			DateTime dt = new DateTime(2042, 12, 24);
			Console.WriteLine(dt.ToString());
		}
	}

}
