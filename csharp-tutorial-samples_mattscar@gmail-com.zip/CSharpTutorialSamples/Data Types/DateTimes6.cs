﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(401, 5443)]
	public class DateTimes6 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			var usCulture = new System.Globalization.CultureInfo("en-US");
			Console.WriteLine("Please specify a date. Format: " + usCulture.DateTimeFormat.ShortDatePattern);
			string dateString = Console.ReadLine();
			DateTime userDate = DateTime.Parse(dateString, usCulture.DateTimeFormat);
			Console.WriteLine("Date entered (long date format):" + userDate.ToLongDateString());
		}
	}

}
