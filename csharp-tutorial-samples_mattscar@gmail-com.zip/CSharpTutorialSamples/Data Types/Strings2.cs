﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(385, 5214)]
	public class Strings2 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			string name = "John Doe";
			int age = 42;
			string userString = String.Format("{0} is {1} years old and lives in {2}", name, age, "New York");
			Console.WriteLine(userString);
		}
	}

}
