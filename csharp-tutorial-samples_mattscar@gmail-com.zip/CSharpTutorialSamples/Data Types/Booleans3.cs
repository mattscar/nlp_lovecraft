﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(383, 5135)]
	public class Booleans3 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			int val = 1;
			bool isAdult = Convert.ToBoolean(val);
			Console.WriteLine("Bool: " + isAdult.ToString());
			Console.WriteLine("Int: " + Convert.ToInt32(isAdult).ToString());
		}
	}

}
