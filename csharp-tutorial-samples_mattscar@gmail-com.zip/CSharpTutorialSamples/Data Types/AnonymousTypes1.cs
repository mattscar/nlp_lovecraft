﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(410, 5511)]
	public class AnonymousTypes1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			var user = new
			{
				Name = "John Doe",
				Age = 42
			};
			Console.WriteLine(user.Name + " - " + user.Age + " years old");
		}
	}

}
