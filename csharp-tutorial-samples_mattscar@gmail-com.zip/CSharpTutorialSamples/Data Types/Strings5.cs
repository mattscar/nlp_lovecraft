﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(385, 5437)]
	public class Strings5 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			string name = "John Doe";
			if(name.Contains("John"))
				Console.WriteLine(name.Replace("John", "Jane"));
			else
				Console.WriteLine("John was not found!");
		}
	}

}
