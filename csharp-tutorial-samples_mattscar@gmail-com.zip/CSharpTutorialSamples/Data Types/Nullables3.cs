﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(382, 5365)]
	public class Nullables3 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			int? nullable = 42;
			if((nullable.HasValue) && (nullable.Value == 42))
				Console.WriteLine("It's 42!");

			if(nullable.GetValueOrDefault() == 42)
				Console.WriteLine("It's 42!");
		}
	}

}
