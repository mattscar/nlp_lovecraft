﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(401, 5266)]
	public class DateTimes3 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			var usCulture = new System.Globalization.CultureInfo("en-US");
			Console.WriteLine(DateTime.Now.ToString(usCulture.DateTimeFormat));
		}
	}

}
