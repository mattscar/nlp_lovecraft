﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(405, 5380)]
	public class DynamicKeyword1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			dynamic user = new
			{
				Name = "John Doe",
				Age = 42
			};
			Console.WriteLine(user.Name + " is " + user.Age + " years old");
		}
	}

}
