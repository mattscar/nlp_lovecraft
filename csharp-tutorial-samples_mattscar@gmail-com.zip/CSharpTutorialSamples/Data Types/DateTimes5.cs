﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(401, 5276)]
	public class DateTimes5 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			DateTime dt = new DateTime(2042, 12, 24, 18, 42, 0);

			Console.WriteLine(dt.ToString("MM'/'dd yyyy"));
			Console.WriteLine(dt.ToString("dd.MM.yyyy"));
			Console.WriteLine(dt.ToString("MM.dd.yyyy HH:mm"));
			Console.WriteLine(dt.ToString("dddd, MMMM (yyyy): HH:mm:ss"));
			Console.WriteLine(dt.ToString("dddd @ hh:mm tt", System.Globalization.CultureInfo.InvariantCulture));
		}
	}

}
