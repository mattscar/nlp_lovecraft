﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(380, 5164)]
	public class Integers4 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			int a = 10;
			int b = 3;

			Console.WriteLine((float)a / b);
		}
	}

}
