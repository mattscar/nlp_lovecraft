﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(380, 5155)]
	public class Integers1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			int a = 42;
			int b = 8;

			Console.WriteLine(a + b);
		}
	}

}
