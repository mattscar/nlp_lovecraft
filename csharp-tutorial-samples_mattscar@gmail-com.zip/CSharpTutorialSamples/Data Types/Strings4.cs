﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(385, 5436)]
	public class Strings4 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			string name = "John Doe";
			Console.WriteLine(name.Replace("John", "Jane"));
		}
	}

}
