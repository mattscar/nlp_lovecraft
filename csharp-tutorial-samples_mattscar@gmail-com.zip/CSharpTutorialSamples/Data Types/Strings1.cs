﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(385, 5210)]
	public class Strings1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			StringBuilder numbers = new StringBuilder();
			for(int i = 0; i < 10000; i++)
				numbers.Append(i);
			Console.WriteLine(numbers.ToString());
		}
	}

}
