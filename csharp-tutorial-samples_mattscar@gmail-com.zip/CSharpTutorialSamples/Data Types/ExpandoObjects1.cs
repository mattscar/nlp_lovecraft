﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(406, 5394)]
	public class ExpandoObjects1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			dynamic user = new System.Dynamic.ExpandoObject();
			user.Name = "John Doe";
			user.Age = 42;
			user.HomeTown = "New York";
			Console.WriteLine(user.Name + " is " + user.Age + " years old and lives in " + user.HomeTown);
		}
	}

}
