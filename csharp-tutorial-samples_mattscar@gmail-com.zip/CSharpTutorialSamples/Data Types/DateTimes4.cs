﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Data_Types
{
	[SampleInfo(401, 5272)]
	public class DateTimes4 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			DateTime dt = new DateTime(2042, 12, 24, 18, 42, 0);

			Console.WriteLine("Short date pattern (d): " + dt.ToString("d"));
			Console.WriteLine("Long date pattern (D): " + dt.ToString("D"));
			Console.WriteLine("Full date/time pattern (F): " + dt.ToString("F"));
			Console.WriteLine("Year/month pattern (y): " + dt.ToString("y"));
		}
	}

}
