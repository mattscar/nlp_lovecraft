﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Culture_and_Regions
{
    [SampleInfo(411, 5776)]
    public class RegionInfo4 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            RegionInfo regionInfo = new RegionInfo(CultureInfo.CurrentCulture.Name);
            Console.WriteLine("Is the metric system used in " + regionInfo.EnglishName + "? " + (regionInfo.IsMetric ? "Yes" : "No"));
        }
    }

}
