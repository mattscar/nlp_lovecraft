﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Culture_and_Regions
{
    [SampleInfo(411, 5772)]
    public class RegionInfo3 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            RegionInfo regionInfo = new RegionInfo("sv-SE");
            Console.WriteLine(regionInfo.CurrencySymbol);
            Console.WriteLine(regionInfo.ISOCurrencySymbol);
            Console.WriteLine(regionInfo.CurrencyEnglishName);
            Console.WriteLine(regionInfo.CurrencyNativeName);
        }
    }

}
