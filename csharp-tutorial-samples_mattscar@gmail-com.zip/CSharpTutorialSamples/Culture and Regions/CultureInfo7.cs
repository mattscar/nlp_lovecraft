﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Culture_and_Regions
{
    [SampleInfo(404, 5705)]
    public class CultureInfo7 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            CultureInfo enUs = new CultureInfo("en-US");
            Console.WriteLine(enUs.DisplayName + ":");
            Console.WriteLine("NumberGroupSeparator: " + enUs.NumberFormat.NumberGroupSeparator);
            Console.WriteLine("NumberDecimalSeparator: " + enUs.NumberFormat.NumberDecimalSeparator);

            CultureInfo deDe = new CultureInfo("de-DE");
            Console.WriteLine(deDe.DisplayName + ":");
            Console.WriteLine("NumberGroupSeparator: " + deDe.NumberFormat.NumberGroupSeparator);
            Console.WriteLine("NumberDecimalSeparator: " + deDe.NumberFormat.NumberDecimalSeparator);
        }
    }

}
