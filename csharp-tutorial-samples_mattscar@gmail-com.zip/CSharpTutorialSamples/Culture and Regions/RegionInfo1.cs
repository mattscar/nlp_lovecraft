﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Culture_and_Regions
{
    [SampleInfo(411, 5766)]
    public class RegionInfo1 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            RegionInfo regionInfo = new RegionInfo("en-US");
            Console.WriteLine(regionInfo.EnglishName);
        }
    }

}
