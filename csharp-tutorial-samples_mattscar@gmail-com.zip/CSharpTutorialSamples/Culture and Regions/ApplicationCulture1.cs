﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Culture_and_Regions
{
    [SampleInfo(428, 5650)]
    public class ApplicationCulture1 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            CultureInfo.CurrentCulture = new CultureInfo("en-US");
            Console.WriteLine("Current culture: " + CultureInfo.CurrentCulture.Name);

            float largeNumber = 12345.67f;
            Console.WriteLine("Number format (Current culture): " + largeNumber.ToString());

            CultureInfo germanCulture = new CultureInfo("de-DE");
            Console.WriteLine("Number format (German): " + largeNumber.ToString(germanCulture));
        }
    }

}
