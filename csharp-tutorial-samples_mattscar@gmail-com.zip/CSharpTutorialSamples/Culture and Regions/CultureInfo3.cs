﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Culture_and_Regions
{
    [SampleInfo(404, 5682)]
    public class CultureInfo3 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            CultureInfo[] neutralCultures = CultureInfo.GetCultures(CultureTypes.NeutralCultures);
            foreach (CultureInfo ci in neutralCultures)
                Console.WriteLine(ci.DisplayName);
            Console.WriteLine("Total: " + neutralCultures.Length);
        }
    }

}
