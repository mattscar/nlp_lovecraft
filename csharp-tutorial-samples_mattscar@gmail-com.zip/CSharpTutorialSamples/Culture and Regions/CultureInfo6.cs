﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Culture_and_Regions
{
    [SampleInfo(404, 5699)]
    public class CultureInfo6 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            CultureInfo enUs = new CultureInfo("en-US");

            foreach (string dayName in enUs.DateTimeFormat.DayNames)
                Console.WriteLine(dayName);
            Console.WriteLine("Today is: " + enUs.DateTimeFormat.GetDayName(DateTime.Now.DayOfWeek));
        }
    }

}
