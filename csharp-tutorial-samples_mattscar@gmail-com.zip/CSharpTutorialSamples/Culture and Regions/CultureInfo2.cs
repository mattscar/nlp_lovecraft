﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Culture_and_Regions
{
    [SampleInfo(404, 5678)]
    public class CultureInfo2 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            CultureInfo[] specificCultures = CultureInfo.GetCultures(CultureTypes.SpecificCultures);
            foreach (CultureInfo ci in specificCultures)
                Console.WriteLine(ci.DisplayName);
            Console.WriteLine("Total: " + specificCultures.Length);
        }
    }

}
