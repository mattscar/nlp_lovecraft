﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Culture_and_Regions
{
    [SampleInfo(411, 5767)]
    public class RegionInfo2 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            RegionInfo regionInfo = new RegionInfo(CultureInfo.CurrentCulture.Name);
            Console.WriteLine(regionInfo.EnglishName);
        }
    }

}
