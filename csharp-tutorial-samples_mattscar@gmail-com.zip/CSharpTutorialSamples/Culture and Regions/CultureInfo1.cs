﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Culture_and_Regions
{
    [SampleInfo(404, 5666)]
    public class CultureInfo1 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            CultureInfo enGb = new CultureInfo("en-GB");
            CultureInfo enUs = new CultureInfo("en-US");
            Console.WriteLine(enGb.DisplayName);
            Console.WriteLine(enUs.DisplayName);
            Console.WriteLine(enGb.Parent.DisplayName);
            Console.WriteLine(enUs.Parent.DisplayName);
        }
    }

}
