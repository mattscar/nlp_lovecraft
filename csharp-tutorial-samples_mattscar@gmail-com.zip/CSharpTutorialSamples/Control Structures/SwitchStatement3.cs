﻿using System;

namespace CSharpTutorial.Samples.Control_Structures
{
	[SampleInfo(111, 1964)]
	public class SwitchStatement3 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			Console.WriteLine("Do you enjoy C# ? (yes/no/maybe)");
			string input = Console.ReadLine();
			switch(input.ToLower())
			{
				case "yes":
				case "maybe":
					Console.WriteLine("Great!");
					break;
				case "no":
					Console.WriteLine("Too bad!");
					break;
				default:
					Console.WriteLine("I'm sorry, I don't understand that!");
					break;
			}
		}
	}
}
