﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Control_Structures
{
	[SampleInfo(111, 1958)]
	public class SwitchStatement1 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			int number = 1;
			switch(number)
			{
				case 0:
					Console.WriteLine("The number is zero!");
					break;
				case 1:
					Console.WriteLine("The number is one!");
					break;
			}
		}
	}
}
