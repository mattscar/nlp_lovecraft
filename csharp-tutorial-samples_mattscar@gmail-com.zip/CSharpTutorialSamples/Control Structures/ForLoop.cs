﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Control_Structures
{
	[SampleInfo(112, 1977)]
	public class ForLoop : IConsoleAppSample
	{
		public void Main(string[] args)
		{

			int number = 5;

			for(int i = 0; i < number; i++)
				Console.WriteLine(i);

			Console.ReadLine();

		}
	}

}
