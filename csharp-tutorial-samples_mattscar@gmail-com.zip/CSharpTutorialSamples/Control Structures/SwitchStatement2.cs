﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Control_Structures
{
	[SampleInfo(111, 1961)]
	public class SwitchStatement2 : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			Console.WriteLine("Do you enjoy C# ? (yes/no/maybe)");
			string input = Console.ReadLine();
			switch(input.ToLower())
			{
				case "yes":
				case "maybe":
					Console.WriteLine("Great!");
					break;
				case "no":
					Console.WriteLine("Too bad!");
					break;
			}
		}
	}
}
