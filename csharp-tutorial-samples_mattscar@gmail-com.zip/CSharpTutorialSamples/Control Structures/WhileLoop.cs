﻿using System;

namespace CSharpTutorial.Samples.Control_Structures
{
	[SampleInfo(112, 1969)]
	public class WhileLoop : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			int number = 0;

			while(number < 5)
			{
				Console.WriteLine(number);
				number = number + 1;
			}

			Console.ReadLine();
		}
	}
}


