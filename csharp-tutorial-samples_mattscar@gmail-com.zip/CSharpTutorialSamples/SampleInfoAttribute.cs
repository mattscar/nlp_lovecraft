﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples
{
	public class SampleInfoAttribute : Attribute
	{

		public SampleInfoAttribute(int articleId, int sampleElementId)
		{
			this.ArticleId = articleId;
			this.SampleElementId = sampleElementId;
		}

		public int ArticleId { get; set; }

		public int SampleElementId { get; set; }
	}
}
