﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Reflection
{
    [SampleInfo(150, 2377)]
    public class Reflection2 : IConsoleAppSample
    {
        public void Main(string[] args)
        {

            string test = "test";
            Console.WriteLine(test.GetType().FullName);
            Console.WriteLine(typeof(Int32).FullName);
            Console.ReadKey();

        }
    }

}
