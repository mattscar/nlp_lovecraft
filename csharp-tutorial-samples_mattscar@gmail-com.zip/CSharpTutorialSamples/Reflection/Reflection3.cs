﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Reflection
{
    [SampleInfo(150, 2380)]
    public class Reflection3 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            Type[] assemblyTypes = assembly.GetTypes();
            foreach (Type t in assemblyTypes)
                Console.WriteLine(t.Name);
            Console.ReadKey();
        }


        class DummyClass
        {
            //Just here to make the output a tad less boring :)
        }
    }
}
