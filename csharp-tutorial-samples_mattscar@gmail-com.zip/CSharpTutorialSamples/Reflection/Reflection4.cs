﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Reflection
{
    [SampleInfo(151, 2383)]
    public class Reflection4 : IConsoleAppSample
    {
        public void Main(string[] args)
        {

            Type testType = typeof(TestClass);
            ConstructorInfo ctor = testType.GetConstructor(System.Type.EmptyTypes);
            if (ctor != null)
            {
                object instance = ctor.Invoke(null);
                MethodInfo methodInfo = testType.GetMethod("TestMethod");
                Console.WriteLine(methodInfo.Invoke(instance, new object[] { 10 }));
            }
            Console.ReadKey();
        }


        public class TestClass
        {
            private int testValue = 42;

            public int TestMethod(int numberToAdd)
            {
                return this.testValue + numberToAdd;

            }
        }
    }
}
