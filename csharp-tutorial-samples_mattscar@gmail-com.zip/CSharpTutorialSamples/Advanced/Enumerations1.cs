﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Advanced
{
    [SampleInfo(131, 2184)]
    public class Enumerations1 : IConsoleAppSample
    {
        public enum Days { Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday }

        public void Main(string[] args)
        {

            Days day = Days.Monday;
            Console.WriteLine((int)day);
            Console.ReadLine();

        }
    }

}
