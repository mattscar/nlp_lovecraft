﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Advanced
{
    [SampleInfo(132, 2205)]
    public class Exceptions2 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            int[] numbers = new int[2];
            try
            {
                numbers[0] = 23;
                numbers[1] = 32;
                numbers[2] = 42;

                foreach (int i in numbers)
                    Console.WriteLine(i);
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine("An index was out of range!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Some sort of error occured: " + ex.Message);
            }
            finally
            {
                Console.WriteLine("It's the end of our try block. Time to clean up!");
            }

        }
    }

}
