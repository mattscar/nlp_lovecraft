﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Advanced
{
    [SampleInfo(131, 2190)]
    public class Enumerations2 : IConsoleAppSample
    {
        public enum Days { Monday = 1, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday }

        public void Main(string[] args)
        {
                string[] values = Enum.GetNames(typeof(Days));
                foreach (string s in values)
                    Console.WriteLine(s);

                Console.ReadLine();
            }
    }

}
