﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Advanced
{
    [SampleInfo(133, 2211)]
    public class Structs1 : IConsoleAppSample
    {
        public void Main(string[] args)
        {

            Car car;

            car = new Car("Blue");
            Console.WriteLine(car.Describe());

            car = new Car("Red");
            Console.WriteLine(car.Describe());

        }

        struct Car
        {
            private string color;

            public Car(string color)
            {
                this.color = color;
            }

            public string Describe()
            {
                return "This car is " + Color;
            }

            public string Color
            {
                get { return color; }
                set
                {
                    color = value;
                }
            }

        }
    }
}
