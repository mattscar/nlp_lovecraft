﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Regular_Expressions
{
    [SampleInfo(418, 5543)]
    public class RegexSearch4 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            string testString = "John Doe, 42 years";
            Regex regex = new Regex(@"^([^,]+),\s([0-9]+)");
            Match match = regex.Match(testString);
            if (match.Success)
                Console.WriteLine("Name: " + match.Groups[1].Value + ". Age: " + match.Groups[2].Value);
        }
    }

}
