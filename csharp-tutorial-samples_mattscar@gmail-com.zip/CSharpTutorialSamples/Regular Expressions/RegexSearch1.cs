﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Regular_Expressions
{
    [SampleInfo(418, 5533)]
    public class RegexSearch1 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            string testString = "John Doe, 42 years";
            Regex regex = new Regex("[0-9]+");
            if (regex.IsMatch(testString))
                Console.WriteLine("String contains numbers!");
            else
                Console.WriteLine("String does NOT contain numbers!");
        }
    }

}
