﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Regular_Expressions
{
    [SampleInfo(418, 5547)]
    public class RegexSearch5 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            string testString = "John Doe, 42 years";
            Regex regex = new Regex(@"^(?<name>[^,]+),\s(?<age>[0-9]+)");
            Match match = regex.Match(testString);
            if (match.Success)
                Console.WriteLine("Name: " + match.Groups["name"].Value + ". Age: " + match.Groups["age"].Value);
        }
    }

}
