﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Regular_Expressions
{
    [SampleInfo(418, 5553)]
    public class RegexSearch6 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            string testString = "123-456-789-0";
            Regex regex = new Regex(@"([0-9]+)");
            MatchCollection matchCollection = regex.Matches(testString);
            foreach (Match match in matchCollection)
                Console.WriteLine("Number found at index " + match.Index + ": " + match.Value);
        }
    }

}
