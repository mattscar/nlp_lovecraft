﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Regular_Expressions
{
    [SampleInfo(418, 5535)]
    public class RegexSearch2 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            string testString = "John Doe, 42 years";
            Regex regex = new Regex("[0-9]+");
            Match match = regex.Match(testString);
            if (match.Success)
                Console.WriteLine("Number found: " + match.Value);
        }
    }

}
