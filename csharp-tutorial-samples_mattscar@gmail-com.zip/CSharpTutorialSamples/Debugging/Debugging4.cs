﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Debugging
{
    [SampleInfo(130, 2172)]
    public class Debugging4 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            for (int i = 0; i < 10; i++)
                Console.WriteLine("i is " + i);
        }
    }

}
