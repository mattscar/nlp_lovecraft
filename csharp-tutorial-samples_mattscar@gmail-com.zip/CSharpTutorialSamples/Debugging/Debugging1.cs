﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Debugging
{
    [SampleInfo(127, 2149)]
    public class Debugging1 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            int a = 5, b = 8, c = 233;
            int d = a + c - b;
            Console.WriteLine(d);
        }
    }

}
