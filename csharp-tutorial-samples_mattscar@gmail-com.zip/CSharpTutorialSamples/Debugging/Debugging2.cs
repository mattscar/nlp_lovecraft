﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Debugging
{
    [SampleInfo(128, 2154)]
    public class Debugging2 : IConsoleAppSample
    {
        public void Main(string[] args)
        {

            int a = 5;
            a = a * 2;
            a = a - 3;
            a = a * 6;
            Console.WriteLine(a);

        }
    }

}
