﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Debugging
{
    [SampleInfo(128, 2157)]
    public class Debugging3 : IConsoleAppSample
    {
        public void Main(string[] args)
        {

            int a = 5;
            int b = 2;
            int result = MakeComplicatedCalculation(a, b);
            Console.WriteLine(result);
        }

        static int MakeComplicatedCalculation(int a, int b)
        {
            return a * b;

        }
    }

}
