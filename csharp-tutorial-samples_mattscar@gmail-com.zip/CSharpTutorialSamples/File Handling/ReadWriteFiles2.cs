﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.File_Handling
{
    [SampleInfo(146, 2329)]
    public class ReadWriteFiles2 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            if (File.Exists("test.txt"))
            {
                string content = File.ReadAllText("test.txt");
                Console.WriteLine("Current content of file:");
                Console.WriteLine(content);
            }
            Console.WriteLine("Please enter new content for the file - type exit and press enter to finish editing:");
            string newContent = Console.ReadLine();
            while (newContent != "exit")
            {
                File.AppendAllText("test.txt", newContent + Environment.NewLine);
                newContent = Console.ReadLine();
            }
        }
    }

}
