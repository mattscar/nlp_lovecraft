﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.File_Handling
{
    [SampleInfo(147, 2350)]
    public class FilesAndDirs4 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            if (Directory.Exists("testdir"))
            {
                Console.WriteLine("Please enter a new name for this directory:");
                string newDirName = Console.ReadLine();
                if (newDirName != String.Empty)
                {
                    Directory.Move("testdir", newDirName);
                    if (Directory.Exists(newDirName))
                    {
                        Console.WriteLine("The directory was renamed to " + newDirName);
                        Console.ReadKey();
                    }
                }
            }
        }
    }

}
