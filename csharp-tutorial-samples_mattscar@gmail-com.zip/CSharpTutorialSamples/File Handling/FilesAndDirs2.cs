﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.File_Handling
{
    [SampleInfo(147, 2342)]
    public class FilesAndDirs2 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            if (Directory.Exists("testdir"))
            {
                Directory.Delete("testdir");
                if (Directory.Exists("testdir") == false)
                    Console.WriteLine("Directory deleted...");
            }
            else
                Console.WriteLine("Directory testdir does not yet exist!");
            Console.ReadKey();
        }
    }

}
