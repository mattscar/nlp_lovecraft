﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.File_Handling
{
    [SampleInfo(147, 2352)]
    public class FilesAndDirs5 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            Console.WriteLine("Please enter a name for the new directory:");
            string newDirName = Console.ReadLine();
            if (newDirName != String.Empty)
            {
                Directory.CreateDirectory(newDirName);
                if (Directory.Exists(newDirName))
                {
                    Console.WriteLine("The directory was created!");
                    Console.ReadKey();
                }
            }
        }
    }

}
