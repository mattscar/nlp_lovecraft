﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.File_Handling
{
    [SampleInfo(148, 2359)]
    public class FileDirInfo2 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            DirectoryInfo di = new DirectoryInfo(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location));
            if (di != null)
            {
                FileInfo[] subFiles = di.GetFiles();
                if (subFiles.Length > 0)
                {
                    Console.WriteLine("Files:");
                    foreach (FileInfo subFile in subFiles)
                    {
                        Console.WriteLine("  " + subFile.Name + " (" + subFile.Length + " bytes)");
                    }
                }
                Console.ReadKey();
            }
        }
    }

}
