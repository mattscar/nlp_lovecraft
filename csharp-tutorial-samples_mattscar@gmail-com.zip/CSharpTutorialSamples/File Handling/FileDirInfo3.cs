﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.File_Handling
{
    [SampleInfo(148, 2362)]
    public class FileDirInfo3 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            DirectoryInfo di = new DirectoryInfo(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location));
            if (di != null)
            {
                DirectoryInfo[] subDirs = di.GetDirectories();
                if (subDirs.Length > 0)
                {
                    Console.WriteLine("Directories:");
                    foreach (DirectoryInfo subDir in subDirs)
                    {
                        Console.WriteLine("  " + subDir.Name);
                    }
                }
            }
        }
    }

}
