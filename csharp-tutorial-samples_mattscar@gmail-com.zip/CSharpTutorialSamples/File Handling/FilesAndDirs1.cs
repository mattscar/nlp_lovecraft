﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.File_Handling
{
    [SampleInfo(147, 2340)]
    public class FilesAndDirs1 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            if (File.Exists("test.txt"))
            {
                File.Delete("test.txt");
                if (File.Exists("test.txt") == false)
                    Console.WriteLine("File deleted...");
            }
            else
                Console.WriteLine("File test.txt does not yet exist!");
            Console.ReadKey();
        }
    }

}
