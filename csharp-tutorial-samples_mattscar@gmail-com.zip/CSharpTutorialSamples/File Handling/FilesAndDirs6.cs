﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.File_Handling
{
    [SampleInfo(147, 5460)]
    public class FilesAndDirs6 : IConsoleAppSample
    {
        public void Main(string[] args)
        {
            string fileContents = "John Doe & Jane Doe sitting in a tree...";
            File.WriteAllText("test.txt", fileContents);

            string fileContentsFromFile = File.ReadAllText("test.txt");
            Console.WriteLine(fileContentsFromFile);
        }
    }

}
