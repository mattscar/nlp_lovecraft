﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutorial.Samples.Getting_Started
{
	[SampleInfo(106, 1907)]
	public class HelloWorld : IConsoleAppSample
	{
		public void Main(string[] args)
		{
			Console.WriteLine("Hello, world!");
			Console.ReadLine();
		}
	}
}
